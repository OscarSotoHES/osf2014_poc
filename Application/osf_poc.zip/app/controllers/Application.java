package controllers;

import models.Citizen;
import models.City;

import com.fasterxml.jackson.databind.JsonNode;

import play.mvc.*;
import play.mvc.BodyParser.Json;

public class Application extends Controller {

    public static Result index() {
        return ok("City & Citizen.");
    }
    
    public static Result cities() {
        return ok(City.find.all().toString());
    }
  
    @BodyParser.Of(Json.class)
    public static Result newCity() {
    	JsonNode json = request().body().asJson();
        String name = json.findPath("name").asText();
        City city = new City(name);
        City.create(city);
    	return ok("City created with name: "+name);
    }
  
    public static Result deleteCity(Long idc) {
    	City.delete(idc);
    	return ok("City with id: "+idc+" is deleted");
    }

    public static Result allCitizen() {
        return ok(Citizen.find.all().toString());
    }
    
    public static Result citizen(Long idc) {
        return ok(City.find.ref(idc).getCitizen().toString());
    }
  
    @BodyParser.Of(Json.class)
    public static Result newCitizen(Long idc) {
    	JsonNode json = request().body().asJson();
        String name = json.findPath("name").asText();
        String first_name = json.findPath("fname").asText();
        Citizen citizen = new Citizen(first_name, name);
        citizen.setCity(City.find.ref(idc));
        Citizen.create(citizen);
    	return ok("Citizen created with name: "+first_name+" "+name+" in city "+City.find.ref(idc).toString());
    }
  
    public static Result deleteCitizen(Long idc, Long id) {
    	Citizen.delete(id);
    	return ok("Citizen with id: "+id+" is deleted");
    }
}
